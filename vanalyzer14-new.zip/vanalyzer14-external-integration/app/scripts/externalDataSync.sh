#!/bin/bash
# External Data Sync Script - Updates KEV and EPSS data

cd /usr/src/app/scripts
/usr/local/bin/python updateExternalScore.py