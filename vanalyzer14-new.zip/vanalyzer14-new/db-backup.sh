#!/bin/bash
set -euo pipefail

# vAnalyzer Database Backup & Restore Script
# Simple and reliable version

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="${SCRIPT_DIR}/backups"
DATE=$(date +"%Y%m%d_%H%M%S")

# Colors
G='\033[0;32m' # Green
R='\033[0;31m' # Red
Y='\033[1;33m' # Yellow
NC='\033[0m'   # No Color

log() { echo -e "[$(date +'%H:%M:%S')] $1"; }
success() { echo -e "${G}✓ $1${NC}"; }
error() { echo -e "${R}✗ $1${NC}"; }
warning() { echo -e "${Y}⚠ $1${NC}"; }

show_usage() {
    echo "Usage: $0 {backup|restore|list}"
    echo ""
    echo "Commands:"
    echo "  backup              - Create database backup"
    echo "  restore <backup>    - Restore from backup directory"
    echo "  list               - List available backups"
    echo ""
    echo "Examples:"
    echo "  $0 backup"
    echo "  $0 restore backups/backup_20250716_123456"
    echo "  $0 list"
}

find_containers() {
    # Find running database containers
    APPDB_CONTAINER=$(docker ps --format "{{.Names}}" | grep -E "(appdb|postgres)" | head -1 || echo "")
    METABASE_CONTAINER=$(docker ps --format "{{.Names}}" | grep -i metabase | head -1 || echo "")
    
    if [[ -z "$APPDB_CONTAINER" ]]; then
        error "No database container found"
        exit 1
    fi
    
    log "Found database container: $APPDB_CONTAINER"
    if [[ -n "$METABASE_CONTAINER" ]]; then
        log "Found Metabase container: $METABASE_CONTAINER"
    fi
}

get_db_info() {
    # Get database credentials
    DB_NAME=$(docker exec "$APPDB_CONTAINER" cat /run/secrets/postgres_db 2>/dev/null || echo "")
    DB_USER=$(docker exec "$APPDB_CONTAINER" cat /run/secrets/postgres_user 2>/dev/null || echo "")
    DB_PASSWORD=$(docker exec "$APPDB_CONTAINER" cat /run/secrets/postgres_password 2>/dev/null || echo "")
    
    if [[ -z "$DB_NAME" || -z "$DB_USER" || -z "$DB_PASSWORD" ]]; then
        error "Cannot read database credentials"
        exit 1
    fi
    
    success "Database: $DB_NAME (user: $DB_USER)"
}

backup_database() {
    local backup_dir="$1"
    local backup_file="${backup_dir}/database_${DB_NAME}_${DATE}.sql"
    
    log "Creating database backup..."
    
    # Create backup using pg_dump inside container
    if docker exec -e PGPASSWORD="$DB_PASSWORD" "$APPDB_CONTAINER" \
        pg_dump -h localhost -p 5432 -U "$DB_USER" -d "$DB_NAME" \
        --clean --create --no-owner --no-privileges \
        -f "/tmp/backup.sql"; then
        
        # Copy backup file out of container
        docker cp "$APPDB_CONTAINER:/tmp/backup.sql" "$backup_file"
        docker exec "$APPDB_CONTAINER" rm -f "/tmp/backup.sql"
        
        local size=$(du -h "$backup_file" | cut -f1)
        success "Database backup created: $(basename "$backup_file") ($size)"
        echo "$backup_file"
    else
        error "Database backup failed"
        return 1
    fi
}

backup_metabase() {
    local backup_dir="$1"
    
    log "Creating Metabase database backup..."
    local metabase_file="${backup_dir}/metabase_db_${DATE}.sql"
    
    # Backup Metabase PostgreSQL database
    if docker exec -e PGPASSWORD="$DB_PASSWORD" "$APPDB_CONTAINER" \
        pg_dump -h localhost -p 5432 -U "$DB_USER" -d metabase \
        --clean --create --no-owner --no-privileges \
        -f "/tmp/metabase_backup.sql" 2>/dev/null; then
        
        # Copy backup file out of container
        docker cp "$APPDB_CONTAINER:/tmp/metabase_backup.sql" "$metabase_file"
        docker exec "$APPDB_CONTAINER" rm -f "/tmp/metabase_backup.sql"
        
        local size=$(du -h "$metabase_file" | cut -f1)
        success "Metabase database backup created: $(basename "$metabase_file") ($size)"
        echo "$metabase_file"
    else
        warning "Metabase database backup failed (database may not exist yet)"
        return 1
    fi
    
    # Also backup Metabase data directory if container exists
    if [[ -n "$METABASE_CONTAINER" ]]; then
        log "Creating Metabase data backup..."
        local metabase_data_file="${backup_dir}/metabase_data_${DATE}.tar"
        
        if docker exec "$METABASE_CONTAINER" tar -cf "/tmp/metabase_data.tar" -C /metabase-data . 2>/dev/null; then
            docker cp "$METABASE_CONTAINER:/tmp/metabase_data.tar" "$metabase_data_file"
            docker exec "$METABASE_CONTAINER" rm -f "/tmp/metabase_data.tar"
            
            local data_size=$(du -h "$metabase_data_file" | cut -f1)
            success "Metabase data backup created: $(basename "$metabase_data_file") ($data_size)"
        else
            warning "Metabase data backup failed"
        fi
    fi
}

create_backup() {
    find_containers
    get_db_info
    
    # Create backup directory
    local backup_name="backup_${DATE}"
    local full_backup_dir="${BACKUP_DIR}/${backup_name}"
    mkdir -p "$full_backup_dir"
    
    log "Creating backup in: $backup_name"
    
    # Backup database
    local db_file=""
    local mb_file=""
    
    if db_file=$(backup_database "$full_backup_dir"); then
        # Backup Metabase
        mb_file=$(backup_metabase "$full_backup_dir" || echo "")
        
        # Create info file
        cat > "${full_backup_dir}/backup_info.txt" << EOF
vAnalyzer Database Backup
========================
Date: $(date)
Database: $DB_NAME
User: $DB_USER
Container: $APPDB_CONTAINER

Files:
- $(basename "$db_file") ($(du -h "$db_file" | cut -f1))
$(if [[ -n "$mb_file" ]]; then echo "- $(basename "$mb_file") ($(du -h "$mb_file" | cut -f1))"; fi)

Restore Command:
$0 restore $backup_name
EOF
        
        success "Backup completed successfully!"
        echo ""
        echo "Backup: $backup_name"
        echo "Location: $full_backup_dir"
        ls -lh "$full_backup_dir"
    else
        error "Backup failed"
        exit 1
    fi
}

restore_database() {
    local backup_dir="$1"
    
    if [[ ! -d "$backup_dir" ]]; then
        error "Backup directory not found: $backup_dir"
        echo ""
        warning "Available backups:"
        if [[ -d "$BACKUP_DIR" ]]; then
            ls -1 "$BACKUP_DIR" | grep "^backup_" 2>/dev/null || echo "  No backups found"
        else
            echo "  No backup directory exists yet"
        fi
        echo ""
        echo "Usage: $0 restore <backup_directory_name>"
        echo "Example: $0 restore backup_20250905_234550"
        exit 1
    fi
    
    find_containers
    get_db_info
    
    # Find backup file
    local backup_file=$(ls "$backup_dir"/*_*.sql 2>/dev/null | grep -v metabase | head -1 || echo "")
    if [[ -z "$backup_file" ]]; then
        error "No main database backup file found in $backup_dir"
        echo "Found files:"
        ls -la "$backup_dir"
        exit 1
    fi
    
    log "Restoring from: $(basename "$backup_file")"
    
    # Confirm restore
    echo -n "This will replace the current database. Continue? (y/N): "
    read -r response
    if [[ ! "$response" =~ ^[Yy]$ ]]; then
        log "Restore cancelled"
        exit 0
    fi
    
    # Copy backup file to container
    docker cp "$backup_file" "$APPDB_CONTAINER:/tmp/restore.sql"
    
    # Restore database
    log "Restoring database..."
    if docker exec -e PGPASSWORD="$DB_PASSWORD" "$APPDB_CONTAINER" \
        psql -h localhost -p 5432 -U "$DB_USER" -d postgres \
        -f "/tmp/restore.sql"; then
        
        docker exec "$APPDB_CONTAINER" rm -f "/tmp/restore.sql"
        success "Database restored successfully"
        
        # Restore Metabase database if available
        local metabase_db_file=$(ls "$backup_dir"/metabase_*.sql 2>/dev/null | head -1 || echo "")
        if [[ -n "$metabase_db_file" ]]; then
            log "Restoring Metabase database..."
            
            # Handle compressed files
            local restore_mb_file="$metabase_db_file"
            if [[ "$metabase_db_file" == *.gz ]]; then
                log "Decompressing Metabase backup file..."
                restore_mb_file="${metabase_db_file%.gz}"
                gunzip -c "$metabase_db_file" > "$restore_mb_file"
            fi
            
            # Copy file to container and restore
            docker cp "$restore_mb_file" "$APPDB_CONTAINER:/tmp/restore_metabase.sql"
            
            if docker exec -e PGPASSWORD="$DB_PASSWORD" "$APPDB_CONTAINER" \
                psql -h localhost -p 5432 -U "$DB_USER" -d postgres \
                -f "/tmp/restore_metabase.sql" 2>/dev/null; then
                
                docker exec "$APPDB_CONTAINER" rm -f "/tmp/restore_metabase.sql"
                success "Metabase database restored"
            else
                warning "Metabase database restore failed"
            fi
            
            # Cleanup
            if [[ "$restore_mb_file" != "$metabase_db_file" ]]; then
                rm -f "$restore_mb_file"
            fi
        fi
        
        # Restore Metabase data directory if available
        local metabase_data_file=$(ls "$backup_dir"/metabase_data_*.tar 2>/dev/null | head -1 || echo "")
        if [[ -n "$metabase_data_file" && -n "$METABASE_CONTAINER" ]]; then
            log "Restoring Metabase data directory..."
            docker cp "$metabase_data_file" "$METABASE_CONTAINER:/tmp/metabase_data.tar"
            
            if docker exec "$METABASE_CONTAINER" sh -c "cd /metabase-data && tar -xf /tmp/metabase_data.tar"; then
                docker exec "$METABASE_CONTAINER" rm -f "/tmp/metabase_data.tar"
                success "Metabase data directory restored"
            else
                warning "Metabase data directory restore failed"
            fi
        fi
        
        success "Restore completed successfully!"
        
        # Important: Stop app service to prevent initialization conflicts
        log "Stopping app service to prevent initialization conflicts..."
        if docker service ls | grep -q "${APPDB_CONTAINER%_*}_app"; then
            docker service scale "${APPDB_CONTAINER%_*}_app"=0
            sleep 5
            docker service scale "${APPDB_CONTAINER%_*}_app"=1
            log "App service restarted - initialization will use restored data"
        fi
    else
        docker exec "$APPDB_CONTAINER" rm -f "/tmp/restore.sql"
        error "Database restore failed"
        exit 1
    fi
}

list_backups() {
    if [[ ! -d "$BACKUP_DIR" ]]; then
        warning "No backup directory found"
        return 0
    fi
    
    log "Available backups:"
    echo ""
    
    local count=0
    for backup_dir in "$BACKUP_DIR"/backup_*; do
        if [[ -d "$backup_dir" ]]; then
            local name=$(basename "$backup_dir")
            local info_file="$backup_dir/backup_info.txt"
            
            echo "📁 $name"
            
            if [[ -f "$info_file" ]]; then
                local date_line=$(grep "Date:" "$info_file" | cut -d':' -f2- | sed 's/^ *//')
                local db_line=$(grep "Database:" "$info_file" | cut -d':' -f2 | sed 's/^ *//')
                echo "   Date: $date_line"
                echo "   Database: $db_line"
                
                # Show files
                echo "   Files:"
                ls -1 "$backup_dir"/*.sql "$backup_dir"/*.tar 2>/dev/null | while read -r file; do
                    local size=$(du -h "$file" | cut -f1)
                    echo "     - $(basename "$file") ($size)"
                done
            else
                echo "   (No info file)"
            fi
            echo ""
            ((count++))
        fi
    done
    
    if [[ $count -eq 0 ]]; then
        warning "No backups found"
    else
        success "Found $count backup(s)"
    fi
}

# Main execution
case "${1:-help}" in
    "backup")
        mkdir -p "$BACKUP_DIR"
        create_backup
        ;;
    "restore")
        if [[ -z "${2:-}" ]]; then
            error "Backup directory required"
            show_usage
            exit 1
        fi
        
        # Handle different path formats
        backup_path="$2"
        
        # If it's already a full path, use as-is
        if [[ "$backup_path" == /* ]]; then
            restore_database "$backup_path"
        # If it starts with backups/, it's relative to script dir
        elif [[ "$backup_path" == backups/* ]]; then
            restore_database "$SCRIPT_DIR/$backup_path"
        # If it's just a backup name, add backup dir
        else
            restore_database "$BACKUP_DIR/$backup_path"
        fi
        ;;
    "list")
        list_backups
        ;;
    "help"|*)
        show_usage
        ;;
esac