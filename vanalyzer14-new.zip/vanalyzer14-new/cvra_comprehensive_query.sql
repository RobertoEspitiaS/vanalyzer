-- CVRA Comprehensive Query for Per-Asset CVE Analysis
-- Combines activevulnerabilities with VulnCheck exploits and KEV data (includes EPSS)
-- Optimized for VulnCheck integration - assumes public KEV/EPSS tables are not present
-- For use in Metabase dashboards and vulnerability risk assessment

WITH cvra_base AS (
  SELECT 
    -- Asset and Vulnerability Core Data
    av.endpoint_id,
    av.asset,
    av.endpoint_hash,
    av.product_name,
    av.cve,
    av.vulnerability_v3_base_score as cvss_score,
    av.sensitivity_level_name,
    av.patch_release_timestamp,
    av.vulnerability_summary,
    
    -- EPSS Threat Intelligence (25% weight) - Use VulnCheck EPSS if available, otherwise fallback
    COALESCE(ve.epss_score, 0.0) as epss_score,
    COALESCE(ve.epss_percentile, 0.0) as epss_percentile,
    
    -- KEV Data (29.2% weight) - Use VulnCheck KEV as primary source
    CASE WHEN vk.cve_id IS NOT NULL THEN 1 ELSE 0 END as is_kev,
    vk.known_ransomware_campaign_use,
    vk.due_date as cisa_due_date,
    vk.required_action,
    vk.date_added as kev_date_added,
    
    -- VulnCheck Exploit Intelligence
    COALESCE(ve.weaponized_exploit_found, false) as weaponized_exploit,
    COALESCE(ve.reported_exploited_by_ransomware, false) as ransomware_exploited,
    COALESCE(ve.reported_exploited_by_threat_actors, false) as apt_exploited,
    COALESCE(ve.public_exploit_found, false) as public_exploit,
    COALESCE(ve.commercial_exploit_found, false) as commercial_exploit,
    ve.max_exploit_maturity,
    COALESCE(ve.exploits_count, 0) as exploit_count,
    COALESCE(ve.threat_actors_count, 0) as threat_actor_count,
    COALESCE(ve.ransomware_families_count, 0) as ransomware_families,
    
    -- VulnCheck KEV Enhanced Data
    vk.vulncheck_reported_exploitation,
    vk.vulncheck_xdb,
    
    -- Patch Analysis (16.7% weight)
    CASE 
      WHEN av.patch_release_timestamp IS NULL THEN 0
      ELSE EXTRACT(DAYS FROM NOW() - av.patch_release_timestamp)
    END as patch_age_days

  FROM activevulnerabilities av
  LEFT JOIN vulncheck_exploits ve ON av.cve = ve.cve_id AND ve.is_active = true
  LEFT JOIN vulncheck_kev vk ON av.cve = vk.cve_id AND vk.is_active = true
)

SELECT 
  *,
  
  -- CVRA Component Scores (0-100 scale)
  
  -- KEV Factor (29.2% weight)
  CASE 
    WHEN is_kev = 1 THEN 100.0
    ELSE 0.0 
  END as kev_factor_score,
  
  -- EPSS Factor (25.0% weight) 
  (epss_score * 100.0) as epss_factor_score,
  
  -- CVSS Factor (20.8% weight)
  CASE 
    WHEN cvss_score >= 9.0 THEN 100.0
    WHEN cvss_score >= 7.0 THEN 75.0  
    WHEN cvss_score >= 4.0 THEN 50.0
    ELSE 25.0
  END as cvss_factor_score,
  
  -- Patch Factor (16.7% weight)
  CASE
    WHEN patch_age_days IS NULL OR patch_age_days = 0 THEN 100.0
    WHEN patch_age_days <= 30 THEN 75.0
    WHEN patch_age_days <= 90 THEN 50.0
    WHEN patch_age_days <= 365 THEN 25.0
    ELSE 100.0
  END as patch_factor_score,
  
  -- Volume Factor (8.3% weight) - simplified as asset exposure
  50.0 as volume_factor_score,
  
  -- Threat Urgency Multiplier (1.0x to 2.5x)
  CASE
    -- Critical: Weaponized + Active Ransomware (2.5x)
    WHEN weaponized_exploit AND ransomware_exploited THEN 2.5
    -- Severe: In KEV or APT exploitation (2.0x) 
    WHEN is_kev = 1 OR apt_exploited THEN 2.0
    -- High: Public exploit or high EPSS (1.5x)
    WHEN public_exploit OR epss_score > 0.5 THEN 1.5
    -- Elevated: Medium EPSS or PoC exists (1.2x)
    WHEN epss_score > 0.2 OR exploit_count > 0 THEN 1.2
    -- Baseline: No active exploitation (1.0x)
    ELSE 1.0
  END as threat_urgency_multiplier,
  
  -- Final CVRA Score Calculation
  ROUND(
    ((
      (CASE WHEN is_kev = 1 THEN 100.0 ELSE 0.0 END * 0.292) +
      ((epss_score * 100.0) * 0.250) +
      (CASE 
        WHEN cvss_score >= 9.0 THEN 100.0
        WHEN cvss_score >= 7.0 THEN 75.0  
        WHEN cvss_score >= 4.0 THEN 50.0
        ELSE 25.0
      END * 0.208) +
      (CASE
        WHEN patch_age_days IS NULL OR patch_age_days = 0 THEN 100.0
        WHEN patch_age_days <= 30 THEN 75.0
        WHEN patch_age_days <= 90 THEN 50.0
        WHEN patch_age_days <= 365 THEN 25.0
        ELSE 100.0
      END * 0.167) +
      (50.0 * 0.083)
    ) *
    CASE
      WHEN weaponized_exploit AND ransomware_exploited THEN 2.5
      WHEN is_kev = 1 OR apt_exploited THEN 2.0
      WHEN public_exploit OR epss_score > 0.5 THEN 1.5
      WHEN epss_score > 0.2 OR exploit_count > 0 THEN 1.2
      ELSE 1.0
    END), 2
  ) as cvra_score,
  
  -- Risk Classification
  CASE
    WHEN ROUND(
      ((
        (CASE WHEN is_kev = 1 THEN 100.0 ELSE 0.0 END * 0.292) +
        ((epss_score * 100.0) * 0.250) +
        (CASE 
          WHEN cvss_score >= 9.0 THEN 100.0
          WHEN cvss_score >= 7.0 THEN 75.0  
          WHEN cvss_score >= 4.0 THEN 50.0
          ELSE 25.0
        END * 0.208) +
        (CASE
          WHEN patch_age_days IS NULL OR patch_age_days = 0 THEN 100.0
          WHEN patch_age_days <= 30 THEN 75.0
          WHEN patch_age_days <= 90 THEN 50.0
          WHEN patch_age_days <= 365 THEN 25.0
          ELSE 100.0
        END * 0.167) +
        (50.0 * 0.083)
      ) *
      CASE
        WHEN weaponized_exploit AND ransomware_exploited THEN 2.5
        WHEN is_kev = 1 OR apt_exploited THEN 2.0
        WHEN public_exploit OR epss_score > 0.5 THEN 1.5
        WHEN epss_score > 0.2 OR exploit_count > 0 THEN 1.2
        ELSE 1.0
      END), 2
    ) >= 75.0 THEN 'CRITICAL'
    WHEN ROUND(
      ((
        (CASE WHEN is_kev = 1 THEN 100.0 ELSE 0.0 END * 0.292) +
        ((epss_score * 100.0) * 0.250) +
        (CASE 
          WHEN cvss_score >= 9.0 THEN 100.0
          WHEN cvss_score >= 7.0 THEN 75.0  
          WHEN cvss_score >= 4.0 THEN 50.0
          ELSE 25.0
        END * 0.208) +
        (CASE
          WHEN patch_age_days IS NULL OR patch_age_days = 0 THEN 100.0
          WHEN patch_age_days <= 30 THEN 75.0
          WHEN patch_age_days <= 90 THEN 50.0
          WHEN patch_age_days <= 365 THEN 25.0
          ELSE 100.0
        END * 0.167) +
        (50.0 * 0.083)
      ) *
      CASE
        WHEN weaponized_exploit AND ransomware_exploited THEN 2.5
        WHEN is_kev = 1 OR apt_exploited THEN 2.0
        WHEN public_exploit OR epss_score > 0.5 THEN 1.5
        WHEN epss_score > 0.2 OR exploit_count > 0 THEN 1.2
        ELSE 1.0
      END), 2
    ) >= 50.0 THEN 'HIGH'
    WHEN ROUND(
      ((
        (CASE WHEN is_kev = 1 THEN 100.0 ELSE 0.0 END * 0.292) +
        ((epss_score * 100.0) * 0.250) +
        (CASE 
          WHEN cvss_score >= 9.0 THEN 100.0
          WHEN cvss_score >= 7.0 THEN 75.0  
          WHEN cvss_score >= 4.0 THEN 50.0
          ELSE 25.0
        END * 0.208) +
        (CASE
          WHEN patch_age_days IS NULL OR patch_age_days = 0 THEN 100.0
          WHEN patch_age_days <= 30 THEN 75.0
          WHEN patch_age_days <= 90 THEN 50.0
          WHEN patch_age_days <= 365 THEN 25.0
          ELSE 100.0
        END * 0.167) +
        (50.0 * 0.083)
      ) *
      CASE
        WHEN weaponized_exploit AND ransomware_exploited THEN 2.5
        WHEN is_kev = 1 OR apt_exploited THEN 2.0
        WHEN public_exploit OR epss_score > 0.5 THEN 1.5
        WHEN epss_score > 0.2 OR exploit_count > 0 THEN 1.2
        ELSE 1.0
      END), 2
    ) >= 25.0 THEN 'MEDIUM'
    ELSE 'LOW'
  END as risk_classification

FROM cvra_base
ORDER BY cvra_score DESC, cvss_score DESC;