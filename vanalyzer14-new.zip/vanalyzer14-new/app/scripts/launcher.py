import logging
import subprocess
import time
import os
from threading import Lock
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.executors.pool import ThreadPoolExecutor
from apscheduler.triggers.interval import IntervalTrigger
from datetime import datetime
import gc

# Configure logging to log to a file
logging.basicConfig(
    filename='/var/log/scheduler_log.log',  # Log file name
    level=logging.INFO,                      # Log level
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',  # Log format
    datefmt='%Y-%m-%d %H:%M:%S'              # Date format for log entries
)
logger = logging.getLogger(__name__)

# Global lock to ensure that jobs do not run concurrently
job_lock = Lock()

def run_bash_script(script_path):
    # Secure path validation to prevent path traversal
    allowed_dir = '/usr/src/app/scripts/'
    real_path = os.path.realpath(script_path)
    
    if not real_path.startswith(os.path.realpath(allowed_dir)):
        logger.error(f"Invalid script path: {script_path}")
        return
    
    if not os.path.exists(real_path):
        logger.error(f"Script does not exist: {script_path}")
        return
        
    try:
        logger.info(f"Starting execution of {script_path} at {datetime.now()}")
        subprocess.run(['bash', script_path], shell=False, check=True)
        logger.info(f"Successfully executed {script_path} at {datetime.now()}")
    except subprocess.CalledProcessError as e:
        logger.error(f"Error executing {script_path}: {e} at {datetime.now()}")
    except Exception as e:
        logger.error(f"Unexpected error executing {script_path}: {e} at {datetime.now()}")
    finally:
        logger.info(f"Finished execution of {script_path} at {datetime.now()}")
    gc.collect()

def full_sync():
    """Run all sync jobs sequentially"""
    with job_lock:
        logger.info("Starting full sync at " + str(datetime.now()))
        
        # Job 1: Refresh Tables
        print("Running job 1 (refreshTables) at " + str(datetime.now()))
        run_bash_script("/usr/src/app/scripts/refreshTables.sh")
        
        # Job 2: Active Vulnerabilities Sync
        print("Running job 2 (activeVulnsSync) at " + str(datetime.now()))
        run_bash_script("/usr/src/app/scripts/activeVulnsSync.sh")
        
        # Job 3: Differential Tables
        print("Running job 3 (difTables) at " + str(datetime.now()))
        run_bash_script("/usr/src/app/scripts/difTables.sh")
        
        # Job 4: External Data Sync (if any external data source is enabled)
        external_enabled = os.environ.get('EXTERNAL_DATA_ENABLED', 'false').lower() == 'true'
        vulncheck_enabled = os.environ.get('VULNCHECK_ENABLED', 'false').lower() == 'true'
        
        if external_enabled or vulncheck_enabled:
            print("Running job 4 (externalDataSync) at " + str(datetime.now()))
            run_bash_script("/usr/src/app/scripts/externalDataSync.sh")
        
        logger.info("Completed full sync at " + str(datetime.now()))

if __name__ == '__main__':
    # Read sync interval from environment variable (default to 6 hours if not set)
    sync_interval = int(os.environ.get('SYNC_INTERVAL', '6'))
    logger.info(f"Configured sync interval: {sync_interval} hours")
    
    # Run the initial tasks before scheduling any other tasks.
    logger.info("Starting initial sync process")
    
    # Initial Task 1: Vicarius data sync
    # The command output is appended to /var/log/initialsync.log.
    initial_command = ["/usr/local/bin/python", "/usr/src/app/scripts/VickyTopiaReportCLI.py", "--allreports"]
    logger.info("Starting initial Vicarius data sync")
    try:
        with open('/var/log/initialsync.log', 'a') as log_file:
            subprocess.run(initial_command, shell=False, check=True, stdout=log_file, stderr=subprocess.STDOUT)
        logger.info("Initial Vicarius data sync completed successfully")
    except subprocess.CalledProcessError as e:
        logger.error(f"Initial Vicarius data sync failed: {e}")
    
    # Initial Task 2: External data sync (if any external data source is enabled)
    external_enabled = os.environ.get('EXTERNAL_DATA_ENABLED', 'false').lower() == 'true'
    vulncheck_enabled = os.environ.get('VULNCHECK_ENABLED', 'false').lower() == 'true'
    
    if external_enabled or vulncheck_enabled:
        logger.info("Starting initial external data sync")
        try:
            subprocess.run(['/usr/local/bin/python', '/usr/src/app/scripts/updateExternalScore.py'], 
                          shell=False, check=True)
            logger.info("Initial external data sync completed successfully")
        except subprocess.CalledProcessError as e:
            logger.error(f"Initial external data sync failed: {e}")
    
    logger.info("Initial sync process completed")

    # Configure a single-threaded executor to ensure non-concurrent execution
    executors = {
        'default': ThreadPoolExecutor(max_workers=1)
    }
    scheduler = BackgroundScheduler(executors=executors)
    
    # Schedule the full sync to run at the configured interval
    scheduler.add_job(full_sync, trigger=IntervalTrigger(hours=sync_interval), misfire_grace_time=1)
    
    logger.info(f"Starting Scheduler with {sync_interval} hour interval at " + str(datetime.now()))
    scheduler.start()
    
    try:
        # Keep the script running
        while True:
            time.sleep(60)
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()
        logger.info("Scheduler shut down at " + str(datetime.now()))
