#!/bin/bash
# vAnalyzer Configuration Management Library
# Simplified .env-only approach

# Create or update a Docker secret
create_or_update_secret() {
    local secret_name="$1"
    local secret_value="$2"
    
    # Remove existing secret if it exists
    if docker secret ls --format "{{.Name}}" 2>/dev/null | grep -q "^${secret_name}$"; then
        docker secret rm "$secret_name" >/dev/null 2>&1 || true
        sleep 1
    fi
    
    # Create new secret
    if echo "$secret_value" | docker secret create "$secret_name" - >/dev/null 2>&1; then
        log_step "Created secret: $secret_name"
    else
        log_error "Failed to create secret: $secret_name"
        return 1
    fi
}

# Initialize configuration with interactive setup
init_configuration() {
    log_info "Starting vAnalyzer Configuration Setup"
    echo ""
    
    # Check for existing configuration
    if [[ -f "$ENV_FILE" ]]; then
        log_warning "Configuration file already exists: $ENV_FILE"
        if ! confirm "Overwrite existing configuration?" "n"; then
            log_info "Configuration setup cancelled"
            return 0
        fi
    fi
    
    # Interactive setup - only 4 essential questions
    interactive_simple_setup
    
    # Generate SSL certificates
    generate_certificates_for_hostname
    
    log_success "Configuration completed successfully"
    echo ""
    log_info "Next step: Run 'vanalyzer deploy' to deploy the stack"
}

# Interactive setup with secure secret handling
interactive_simple_setup() {
    echo -e "${BOLD}vAnalyzer Configuration Setup${NC}"
    echo ""
    
    # Hostname
    local vanalyzer_hostname=""
    while [[ -z "$vanalyzer_hostname" ]]; do
        read -p "Enter vAnalyzer hostname (e.g., reports.company.com): " vanalyzer_hostname
        if [[ -z "$vanalyzer_hostname" ]]; then
            log_error "Hostname is required"
        fi
    done
    
    # Dashboard ID
    local dashboard_id=""
    while [[ -z "$dashboard_id" ]]; do
        local input_dashboard=""
        read -p "Enter Dashboard ID or URL (e.g., 'company' or 'https://company.vicarius.cloud'): " input_dashboard
        if [[ -z "$input_dashboard" ]]; then
            log_error "Dashboard ID is required"
            continue
        fi
        
        # Extract dashboard ID from URL if full URL provided
        if [[ "$input_dashboard" =~ ^https?://([^.]+)\.vicarius\.cloud ]]; then
            dashboard_id="${BASH_REMATCH[1]}"
            log_success "Extracted dashboard ID: $dashboard_id from URL"
        elif [[ "$input_dashboard" =~ ^([^.]+)\.vicarius\.cloud ]]; then
            dashboard_id="${BASH_REMATCH[1]}"
            log_success "Extracted dashboard ID: $dashboard_id from domain"
        else
            dashboard_id="$input_dashboard"
        fi
        
        # Validate dashboard ID format (alphanumeric, hyphens, underscores)
        if [[ ! "$dashboard_id" =~ ^[a-zA-Z0-9_-]+$ ]]; then
            log_error "Invalid dashboard ID format. Use only letters, numbers, hyphens, and underscores."
            dashboard_id=""
        fi
    done
    
    # API Key
    local api_key=""
    while [[ -z "$api_key" ]]; do
        read -s -p "Enter API Key: " api_key
        echo ""
        if [[ -z "$api_key" ]]; then
            log_error "API Key is required"
        fi
    done
    
    # PostgreSQL Username
    local db_user=""
    read -p "Enter PostgreSQL username (default: vanalyzer): " db_user
    db_user="${db_user:-vanalyzer}"
    
    # Database Name
    local db_name=""
    read -p "Enter database name (default: vanalyzer): " db_name
    db_name="${db_name:-vanalyzer}"
    
    # Database Password
    local db_password=""
    while [[ -z "$db_password" ]]; do
        read -s -p "Enter Database Password: " db_password
        echo ""
        if [[ -z "$db_password" ]]; then
            log_error "Database password is required"
        fi
        
        read -s -p "Confirm password: " db_password_confirm
        echo ""
        
        if [[ "$db_password" != "$db_password_confirm" ]]; then
            log_error "Passwords do not match"
            db_password=""
        fi
    done
    
    # Optional: Sync interval
    echo ""
    read -p "Sync interval in hours (default: 6): " sync_interval
    sync_interval="${sync_interval:-6}"
    # Remove any 'h' suffix if user added it
    sync_interval="${sync_interval%h}"
    
    # Optional: External data sources (KEV + EPSS)
    echo ""
    read -p "Enable external vulnerability data (KEV + EPSS)? [y/N]: " enable_external
    external_data_enabled="false"
    epss_url=""
    kev_url=""
    
    if [[ "$enable_external" =~ ^[Yy] ]]; then
        external_data_enabled="true"
        
        # Ask about custom URLs
        read -p "Use custom data source URLs? [y/N]: " custom_urls
        if [[ "$custom_urls" =~ ^[Yy] ]]; then
            echo "Leave blank to use defaults:"
            read -p "EPSS URL [https://epss.empiricalsecurity.com/epss_scores-current.csv.gz]: " epss_url_input
            epss_url="${epss_url_input:-https://epss.empiricalsecurity.com/epss_scores-current.csv.gz}"
            
            read -p "KEV URL [https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json]: " kev_url_input
            kev_url="${kev_url_input:-https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json}"
        else
            epss_url="https://epss.empiricalsecurity.com/epss_scores-current.csv.gz"
            kev_url="https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
        fi
        
        log_success "External data sources (KEV + EPSS) configured"
    else
        log_info "External data sources (KEV + EPSS) disabled"
    fi
    
    # Vulncheck integration (independent of KEV/EPSS)
    echo ""
    read -p "Enable Vulncheck.com integration (requires API key)? [y/N]: " enable_vulncheck
    vulncheck_enabled="false"
    
    if [[ "$enable_vulncheck" =~ ^[Yy] ]]; then
        vulncheck_enabled="true"
        
        # Get Vulncheck API key
        local vulncheck_api_key=""
        while [[ -z "$vulncheck_api_key" ]]; do
            read -s -p "Enter Vulncheck API key: " vulncheck_api_key
            echo ""
            if [[ -z "$vulncheck_api_key" ]]; then
                log_error "Vulncheck API key is required"
            fi
        done
        
        # Create Vulncheck secret
        if ! create_or_update_secret "vulncheck_api_key" "$vulncheck_api_key"; then
            log_error "Failed to create vulncheck_api_key secret"
            return 1
        fi
        log_success "Vulncheck integration configured"
    else
        log_info "Vulncheck integration disabled"
    fi
    
    # Create .env file with NON-SENSITIVE configuration only
    cat > "$ENV_FILE" <<EOF
# vAnalyzer Configuration
# Generated: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
# NOTE: Sensitive data (API key, passwords) are stored in Docker secrets, not here

# Public Configuration
VANALYZER_HOSTNAME=$vanalyzer_hostname
DB_USER=$db_user
DB_NAME=$db_name
SYNC_INTERVAL=$sync_interval
METABASE_MEMORY=2g

# External Data Sources
EXTERNAL_DATA_ENABLED=$external_data_enabled
EPSS_URL=$epss_url
KEV_URL=$kev_url
VULNCHECK_ENABLED=$vulncheck_enabled

# Generated Settings
PROJECT_NAME=vanalyzer
VERSION=1.4
ENVIRONMENT=production
APP_PORT=8000
LOG_LEVEL=INFO
TRAEFIK_VERSION=latest
TRAEFIK_DASHBOARD_PORT=8080
METABASE_VERSION=v0.55.x
METABASE_HOST=$vanalyzer_hostname
STACK_NAME=vanalyzer-stack
COMPOSE_PROJECT_NAME=vanalyzer
HEALTH_CHECK_INTERVAL=30s
HEALTH_CHECK_TIMEOUT=10s
HEALTH_CHECK_RETRIES=3
HEALTH_CHECK_START_PERIOD=40s
USE_LOCAL_CA=true
SSL_CA_FILE=ca.crt
SSL_KEY_FILE=$vanalyzer_hostname.key
SSL_CRT_FILE=$vanalyzer_hostname.crt
EOF
    
    # Set proper permissions - readable by owner and group, but not world
    chmod 640 "$ENV_FILE"
    # Ensure ownership is correct (important when run with sudo)
    if [[ "${SUDO_USER:-}" ]]; then
        chown "${SUDO_USER}:${SUDO_USER}" "$ENV_FILE"
        log_step "Set ownership to ${SUDO_USER}:${SUDO_USER}"
    fi
    log_success "Configuration saved to: $ENV_FILE (non-sensitive data only)"
    
    # Create Docker secrets immediately (sensitive data)
    log_info "Creating Docker secrets for sensitive data..."
    
    # Ensure Docker Swarm is initialized
    if ! docker info 2>/dev/null | grep -q "Swarm: active"; then
        if ! init_swarm; then
            log_error "Failed to initialize Docker Swarm during configuration"
            log_warning "You may need to initialize it manually: docker swarm init"
        fi
    fi
    
    # Stop existing services to allow secret updates
    local stack_name="${STACK_NAME:-vanalyzer-stack}"
    if docker stack ls --format "{{.Name}}" 2>/dev/null | grep -q "^${stack_name}$"; then
        log_step "Stopping existing services to update secrets..."
        docker stack rm "$stack_name" >/dev/null 2>&1 || true
        # Wait for stack to be fully removed
        while docker stack ls --format "{{.Name}}" 2>/dev/null | grep -q "^${stack_name}$"; do
            sleep 2
        done
        log_success "Services stopped"
    fi
    
    # Create or update secrets
    create_or_update_secret "api_key" "$api_key"
    create_or_update_secret "dashboard_id" "$dashboard_id"
    create_or_update_secret "postgres_user" "$db_user"
    create_or_update_secret "postgres_password" "$db_password"
    create_or_update_secret "postgres_db" "$db_name"
    create_or_update_secret "optional_tools" "metabase"
    
    log_success "Docker secrets created successfully"
    
    # Clear sensitive variables from memory
    unset api_key
    unset db_password
    unset dashboard_id
}

# Load configuration from .env file
load_env_configuration() {
    if [[ ! -f "$ENV_FILE" ]]; then
        log_error "Configuration file not found: $ENV_FILE"
        return 1
    fi
    
    # Source the .env file
    source "$ENV_FILE"
    log_success "Configuration loaded from: $ENV_FILE"
}

# Backup function removed to prevent file clutter

# Generate certificates for configured hostname
generate_certificates_for_hostname() {
    if [[ ! -f "$ENV_FILE" ]]; then
        log_error "Configuration file not found"
        return 1
    fi
    
    # Load hostname from .env
    source "$ENV_FILE"
    local hostname="$VANALYZER_HOSTNAME"
    
    if [[ -z "$hostname" ]]; then
        log_error "Hostname not found in configuration"
        return 1
    fi
    
    log_info "Generating SSL certificates for: $hostname"
    
    # Use existing generate-ssl-certs.sh if available
    if [[ -f "${SCRIPT_DIR}/generate-ssl-certs.sh" ]]; then
        "${SCRIPT_DIR}/generate-ssl-certs.sh" create-all "$hostname"
    else
        log_warning "SSL certificate script not found, skipping certificate generation"
        log_info "Run 'vanalyzer certs generate $hostname' to generate certificates"
    fi
}

# Validate configuration
validate_configuration() {
    log_info "Validating configuration..."
    echo ""
    
    local errors=0
    local warnings=0
    
    # Check .env file
    if [[ -f "$ENV_FILE" ]]; then
        echo -e "  Environment file:   ${GREEN}✓${NC} Found"
        
        # Load configuration
        source "$ENV_FILE"
        
        # Check required fields in .env (non-sensitive)
        local required_env_fields=("VANALYZER_HOSTNAME" "DB_USER" "DB_NAME")
        for field in "${required_env_fields[@]}"; do
            if grep -q "^${field}=" "$ENV_FILE" && [[ -n "$(grep "^${field}=" "$ENV_FILE" | cut -d'=' -f2-)" ]]; then
                echo -e "  Config '$field':    ${GREEN}✓${NC} Present"
            else
                echo -e "  Config '$field':    ${RED}✗${NC} Missing"
                ((errors++))
            fi
        done
        
        # Check required Docker secrets (sensitive data)
        echo ""
        echo "  Checking Docker secrets:"
        local required_secrets=("api_key" "dashboard_id" "postgres_user" "postgres_password" "postgres_db")
        for secret in "${required_secrets[@]}"; do
            if docker secret ls --format "{{.Name}}" 2>/dev/null | grep -q "^${secret}$"; then
                echo -e "  Secret '$secret':   ${GREEN}✓${NC} Present"
            else
                echo -e "  Secret '$secret':   ${RED}✗${NC} Missing"
                ((errors++))
            fi
        done
        
        # Check certificates
        local hostname=$(grep "^VANALYZER_HOSTNAME=" "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '"')
        if [[ -n "$hostname" ]]; then
            local cert_file="${SCRIPT_DIR}/traefik/config/certs/${hostname}.crt"
            local key_file="${SCRIPT_DIR}/traefik/config/certs/${hostname}.key"
            
            if [[ -f "$cert_file" ]] && [[ -f "$key_file" ]]; then
                echo -e "  SSL certificates:   ${GREEN}✓${NC} Found"
            else
                echo -e "  SSL certificates:   ${YELLOW}⚠${NC} Not found (will be generated)"
                ((warnings++))
            fi
        else
            echo -e "  SSL certificates:   ${YELLOW}⚠${NC} No hostname configured"
            ((warnings++))
        fi
    else
        echo -e "  Environment file:   ${RED}✗${NC} Not found"
        echo -e "                      Run 'vanalyzer init' to create configuration"
        ((errors++))
    fi
    
    echo ""
    
    # Check Docker
    if check_runtime 2>/dev/null; then
        echo -e "  Container runtime:  ${GREEN}✓${NC} ${RUNTIME} running"
    else
        echo -e "  Container runtime:  ${RED}✗${NC} Not running"
        ((errors++))
    fi
    
    # Check Swarm
    if docker info 2>/dev/null | grep -q "Swarm: active"; then
        echo -e "  Docker Swarm:       ${GREEN}✓${NC} Active"
    else
        echo -e "  Docker Swarm:       ${YELLOW}⚠${NC} Not initialized"
        ((warnings++))
    fi
    
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    if [[ $errors -eq 0 ]]; then
        if [[ $warnings -eq 0 ]]; then
            echo -e "${GREEN}✓ Configuration is valid and ready${NC}"
        else
            echo -e "${YELLOW}⚠ Configuration has $warnings warning(s)${NC}"
            echo "  These will be addressed during deployment"
        fi
        return 0
    else
        echo -e "${RED}✗ Configuration has $errors error(s)${NC}"
        echo "  Please run 'vanalyzer init' to fix configuration"
        return 1
    fi
}

# Export simplified config functions
export -f create_or_update_secret
export -f init_configuration interactive_simple_setup
export -f load_env_configuration
export -f generate_certificates_for_hostname validate_configuration